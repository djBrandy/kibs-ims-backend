-- Fix audit_logs table structure
ALTER TABLE audit_logs MODIFY COLUMN previous_value LONGTEXT;
ALTER TABLE audit_logs MODIFY COLUMN new_value LONGTEXT;
ALTER TABLE audit_logs MODIFY COLUMN notes LONGTEXT;

-- Add last_audit_time to products table if it doesn't exist
ALTER TABLE products ADD COLUMN IF NOT EXISTS last_audit_time DATETIME NULL;

-- Update existing products to allow editing
UPDATE products SET last_audit_time = NULL WHERE last_audit_time IS NULL;